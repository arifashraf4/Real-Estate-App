//
//  Deal+CoreDataClass.swift
//  Real Estate App
//
//  Created by arifashraf on 02/02/22.
//
//

import Foundation
import CoreData

@objc(Deal)
public class Deal: NSManagedObject {

}
