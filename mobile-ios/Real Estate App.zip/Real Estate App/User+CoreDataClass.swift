//
//  User+CoreDataClass.swift
//  Real Estate App
//
//  Created by arifashraf on 02/02/22.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
